export interface IDeviceData {
  id: number;
  name: string;
  device: string;
  path: string;
  status: string;
  isSelected?: boolean;
  isDisabled?: boolean;
}
