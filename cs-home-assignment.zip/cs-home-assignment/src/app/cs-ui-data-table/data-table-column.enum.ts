export enum dataTableColumnEnum {
  Null = '',
  Id = 'id',
  Name = 'name',
  Device = 'device',
  Path = 'path',
  Status = 'status',
}
