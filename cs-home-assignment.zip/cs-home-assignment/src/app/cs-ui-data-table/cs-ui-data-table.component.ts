import { Component, EventEmitter, Input, OnInit } from '@angular/core';
import { IDeviceData } from '../device-data-table/i-device-data.component';
import { IDeviceModalData } from '../device-data-table/i-device-modal-data.component';
import { ITableColumn } from './i-table-column';

@Component({
  selector: 'cs-ui-data-table',
  templateUrl: './cs-ui-data-table.component.html',
  styleUrls: ['./cs-ui-data-table.component.scss'],
})
export class CSDataTableComponent implements OnInit {
  @Input()
  public columns: ITableColumn[] = null;
  @Input()
  public rows: IDeviceData[] = [];
  public event: EventEmitter<void> = new EventEmitter();

  public isAllChecked: boolean = false;
  public selectedDeviceList: IDeviceData[] = [];
  public downloadDeviceList: IDeviceModalData[] = [];
  public SelectedDeviceCount: string = 'None Selected';
  public isIndeterminate: boolean = false;
  public deviceFormattedData: IDeviceData[] = [];
  public modalTitle = "Download - Available Device List"

  constructor() {}

  public ngOnInit(): void {
    this.deviceFormattedData = this.rows.map((data: IDeviceData) => {
      return {
        id: data.id,
        name: data.name,
        device: data.device,
        path: data.path,
        status: this.toFirstLetterCapitalize(data.status),
        isSelected: data.isSelected,
      };
    });
  }

  public checkUncheckAll() {
    for (var i = 0; i < this.deviceFormattedData.length; i++) {
      this.deviceFormattedData[i].isSelected = this.isAllChecked;
    }
    this.getCheckedDeviceList();
  }

  /** To capitalize first letter of status */
  public toFirstLetterCapitalize(status: string) {
    return status.charAt(0).toUpperCase() + status.slice(1).toLowerCase();
  }

  public isAllSelected() {
    this.isAllChecked = this.deviceFormattedData.every((item: IDeviceData) => {
      return item.isSelected === true;
    });
    this.getCheckedDeviceList();
  }

  public getCheckedDeviceList() {
    /** To get selected device list */
    this.selectedDeviceList = [];
    for (var i = 0; i < this.deviceFormattedData.length; i++) {
      if (this.deviceFormattedData[i].isSelected) {
        this.selectedDeviceList.push(this.deviceFormattedData[i]);
      }

      /** To count and show selected checkbox */
      this.SelectedDeviceCount =
        this.selectedDeviceList.length > 0
          ? `${this.selectedDeviceList.length} Selected`
          : 'None Selected';

      /** To determine indeterminate state of checkbox */
      this.isIndeterminate =
        this.selectedDeviceList.length > 0 && this.isAllChecked !== true
          ? true
          : false;

      /** To get Modal data - Filtered device with status available*/
      this.downloadDeviceList = this.selectedDeviceList.filter(
        (deviceData: IDeviceData): IDeviceModalData => {
          if (deviceData.status === 'Available') {
            return {
              id: deviceData.id,
              device: deviceData.device,
              path: deviceData.path,
            };
          }

          return null;
        }
      );
    }
  }

  /** To open Modal */
  public onClickOpenModal() {
    this.event.emit();
  }
}
