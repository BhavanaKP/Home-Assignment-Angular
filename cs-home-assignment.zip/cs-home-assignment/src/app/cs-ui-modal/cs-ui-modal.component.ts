import { Component, EventEmitter, Input, OnInit } from '@angular/core';
import { IDeviceModalData } from '../device-data-table/i-device-modal-data.component';

@Component({
  selector: 'cs-ui-modal',
  templateUrl: './cs-ui-modal.component.html',
  styleUrls: ['./cs-ui-modal.component.scss'],
})
export class CSModalComponent implements OnInit {
  @Input()
  public event: EventEmitter<void>;
  @Input()
  public modalData: IDeviceModalData[] = [];
  @Input()
  public modalTitle: string = "";

  constructor() {}

  public ngOnInit(): void {
    var modal = document.getElementById('modalSection');

    this.event.subscribe(() => {
      modal.style.display = 'block';
    });

    const closeButton = document.getElementById('btn');
    closeButton.onclick = function () {
      modal.style.display = 'none';
    };

    // When the user clicks anywhere outside of the modal, close modal
    window.onclick = function (event) {
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    };
  }
}
