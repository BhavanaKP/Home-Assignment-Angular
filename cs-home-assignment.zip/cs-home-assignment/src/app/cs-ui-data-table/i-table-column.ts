export interface ITableColumn {
  label: string;
  key: string;
}
