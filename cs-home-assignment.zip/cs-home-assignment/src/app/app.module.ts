import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CSDataTableComponent } from './cs-ui-data-table/cs-ui-data-table.component';
import { CSModalComponent } from './cs-ui-modal/cs-ui-modal.component';
import { DeviceDataTableComponent } from './device-data-table/device-data-table.component';

@NgModule({
  declarations: [
    AppComponent,
    DeviceDataTableComponent,
    CSDataTableComponent,
    CSModalComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
