export enum dataTableColumnLableEnum {
  Null = '',
  Name = 'Name',
  Device = 'Device',
  Path = 'Path',
  Status = 'Status',
}
