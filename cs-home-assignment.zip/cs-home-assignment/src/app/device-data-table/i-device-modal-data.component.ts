export interface IDeviceModalData {
  id: number;
  device: string;
  path: string;
}
