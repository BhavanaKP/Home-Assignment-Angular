import { Component } from '@angular/core';

import { IDeviceData } from './i-device-data.component';
import { deviceMockData } from '../mock-data/device-mock-data';
import { dataTableColumnLableEnum } from '../cs-ui-data-table/data-table-column-lable.enum';
import { dataTableColumnEnum } from '../cs-ui-data-table/data-table-column.enum';
import { ITableColumn } from '../cs-ui-data-table/i-table-column';

@Component({
  selector: 'device-data-table',
  templateUrl: './device-data-table.component.html',
  styleUrls: ['./device-data-table.component.scss'],
})
export class DeviceDataTableComponent {
  // Given Mock-Data, you can change device-mock-data.ts file to test the different scenarios
  public deviceMockData: IDeviceData[] = deviceMockData;

  /** Table columns label with key */
  public columns: ITableColumn[] = [
    {
      label: dataTableColumnLableEnum.Null,
      key: dataTableColumnEnum.Id,
    },
    {
      label: dataTableColumnLableEnum.Name,
      key: dataTableColumnEnum.Name,
    },
    {
      label: dataTableColumnLableEnum.Device,
      key: dataTableColumnEnum.Device,
    },
    {
      label: dataTableColumnLableEnum.Path,
      key: dataTableColumnEnum.Device,
    },
    {
      label: dataTableColumnLableEnum.Null,
      key: dataTableColumnEnum.Null,
    },
    {
      label: dataTableColumnLableEnum.Status,
      key: dataTableColumnEnum.Status,
    },
  ];

  constructor() {}
}
